sap.ui.define([
	'jquery.sap.global',
	'sap/ui/core/mvc/Controller',
	'sap/ui/model/json/JSONModel',
	'sap/m/MessageToast',
	'de/enercon/usbee/controller/utils/Formatter'

], function (jQuery, Controller, JSONModel, MessageToast, Formatter) {
	"use strict";

	var PageController = Controller.extend("de.enercon.usbee.controller.home_tilemenu", {

		onInit: function (evt) {

		}


	});
	return PageController;

});